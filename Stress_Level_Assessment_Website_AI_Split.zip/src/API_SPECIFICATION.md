# API Specification - SAD Assessment

Spesifikasi API untuk integrasi backend dengan aplikasi SAD Assessment.

## Base URL

```
Development: http://localhost:8080/api
Production: https://api.sadassessment.com/api
```

## Authentication

Semua endpoint yang memerlukan authentication menggunakan JWT Bearer token:

```
Authorization: Bearer <token>
```

---

## Endpoints

### 1. Authentication

#### POST `/auth/register`

Registrasi user baru.

**Request Body:**
```json
{
  "email": "student@university.ac.id",
  "password": "securepassword123",
  "name": "Nama Lengkap"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_1234567890",
      "email": "student@university.ac.id",
      "name": "Nama Lengkap",
      "studentId": "",
      "age": 0,
      "gender": "",
      "university": "",
      "department": "",
      "photoUrl": null,
      "createdAt": "2024-01-15T10:30:00Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "message": "Registration successful"
}
```

**Error Response (400 Bad Request):**
```json
{
  "success": false,
  "error": {
    "code": "EMAIL_EXISTS",
    "message": "Email already registered"
  }
}
```

---

#### POST `/auth/login`

Login user.

**Request Body:**
```json
{
  "email": "student@university.ac.id",
  "password": "securepassword123"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_1234567890",
      "email": "student@university.ac.id",
      "name": "Nama Lengkap",
      "studentId": "12345678",
      "age": 19,
      "gender": "male",
      "university": "Universitas Indonesia",
      "department": "Ilmu Komputer",
      "photoUrl": "https://storage.example.com/photos/usr_1234567890.jpg",
      "createdAt": "2024-01-15T10:30:00Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "message": "Login successful"
}
```

**Error Response (401 Unauthorized):**
```json
{
  "success": false,
  "error": {
    "code": "INVALID_CREDENTIALS",
    "message": "Email or password is incorrect"
  }
}
```

---

### 2. User Profile

#### GET `/users/:userId`

Get user profile.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "usr_1234567890",
    "email": "student@university.ac.id",
    "name": "Nama Lengkap",
    "studentId": "12345678",
    "age": 19,
    "gender": "male",
    "university": "Universitas Indonesia",
    "department": "Ilmu Komputer",
    "photoUrl": "https://storage.example.com/photos/usr_1234567890.jpg",
    "createdAt": "2024-01-15T10:30:00Z",
    "updatedAt": "2024-01-20T14:22:00Z"
  }
}
```

---

#### PUT `/users/:userId`

Update user profile.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "name": "Nama Baru",
  "studentId": "12345678",
  "age": 19,
  "gender": "male",
  "university": "Universitas Indonesia",
  "department": "Teknik Informatika"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "usr_1234567890",
    "email": "student@university.ac.id",
    "name": "Nama Baru",
    "studentId": "12345678",
    "age": 19,
    "gender": "male",
    "university": "Universitas Indonesia",
    "department": "Teknik Informatika",
    "photoUrl": "https://storage.example.com/photos/usr_1234567890.jpg",
    "updatedAt": "2024-01-20T15:00:00Z"
  },
  "message": "Profile updated successfully"
}
```

---

#### POST `/users/:userId/photo`

Upload user photo.

**Headers:**
```
Authorization: Bearer <token>
Content-Type: multipart/form-data
```

**Request:**
```
Form Data:
  photo: [File]
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "photoUrl": "https://storage.example.com/photos/usr_1234567890.jpg"
  },
  "message": "Photo uploaded successfully"
}
```

---

### 3. Assessment Results

#### POST `/results`

Save assessment result.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "userId": "usr_1234567890",
  "assessments": [
    {
      "type": "PSS10",
      "score": 18,
      "category": "MODERATE",
      "percentage": 45
    },
    {
      "type": "GAD7",
      "score": 8,
      "category": "MODERATE",
      "percentage": 38
    },
    {
      "type": "PHQ9",
      "score": 6,
      "category": "MODERATE",
      "percentage": 22
    }
  ],
  "answers": [1, 2, 1, 3, 2, 1, 2, 3, 1, 2, 0, 1, 2, 1, 0, 1, 2, 0, 1, 2, 1, 0, 1, 2, 0, 1],
  "timestamp": "2024-01-20T15:30:00Z"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "res_9876543210",
    "userId": "usr_1234567890",
    "assessments": [
      {
        "type": "PSS10",
        "score": 18,
        "category": "MODERATE",
        "percentage": 45
      },
      {
        "type": "GAD7",
        "score": 8,
        "category": "MODERATE",
        "percentage": 38
      },
      {
        "type": "PHQ9",
        "score": 6,
        "category": "MODERATE",
        "percentage": 22
      }
    ],
    "timestamp": "2024-01-20T15:30:00Z",
    "createdAt": "2024-01-20T15:30:05Z"
  },
  "message": "Result saved successfully"
}
```

---

#### GET `/results/user/:userId`

Get all results for a user.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `limit` (optional): Number of results to return (default: 10)
- `offset` (optional): Pagination offset (default: 0)
- `sortBy` (optional): Sort field (default: "timestamp")
- `order` (optional): Sort order "asc" or "desc" (default: "desc")

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "results": [
      {
        "id": "res_9876543210",
        "userId": "usr_1234567890",
        "assessments": [
          {
            "type": "PSS10",
            "score": 18,
            "category": "MODERATE",
            "percentage": 45
          },
          {
            "type": "GAD7",
            "score": 8,
            "category": "MODERATE",
            "percentage": 38
          },
          {
            "type": "PHQ9",
            "score": 6,
            "category": "MODERATE",
            "percentage": 22
          }
        ],
        "timestamp": "2024-01-20T15:30:00Z",
        "createdAt": "2024-01-20T15:30:05Z"
      }
    ],
    "pagination": {
      "total": 5,
      "limit": 10,
      "offset": 0,
      "hasMore": false
    }
  }
}
```

---

#### GET `/results/:resultId`

Get specific result by ID.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "res_9876543210",
    "userId": "usr_1234567890",
    "user": {
      "name": "Nama Lengkap",
      "studentId": "12345678",
      "university": "Universitas Indonesia"
    },
    "assessments": [
      {
        "type": "PSS10",
        "score": 18,
        "category": "MODERATE",
        "percentage": 45
      },
      {
        "type": "GAD7",
        "score": 8,
        "category": "MODERATE",
        "percentage": 38
      },
      {
        "type": "PHQ9",
        "score": 6,
        "category": "MODERATE",
        "percentage": 22
      }
    ],
    "answers": [1, 2, 1, 3, 2, 1, 2, 3, 1, 2, 0, 1, 2, 1, 0, 1, 2, 0, 1, 2, 1, 0, 1, 2, 0, 1],
    "timestamp": "2024-01-20T15:30:00Z",
    "createdAt": "2024-01-20T15:30:05Z"
  }
}
```

---

#### GET `/results/:resultId/pdf`

Download result as PDF.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
- Content-Type: `application/pdf`
- Binary PDF file

---

### 4. Statistics (Admin)

#### GET `/admin/statistics`

Get overall statistics.

**Headers:**
```
Authorization: Bearer <admin_token>
```

**Query Parameters:**
- `startDate` (optional): Filter from date (ISO 8601)
- `endDate` (optional): Filter to date (ISO 8601)
- `university` (optional): Filter by university

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "totalUsers": 1250,
    "totalAssessments": 3420,
    "averageScores": {
      "PSS10": 16.5,
      "GAD7": 7.2,
      "PHQ9": 8.1
    },
    "categoryDistribution": {
      "PSS10": {
        "LIGHT": 35,
        "MODERATE": 45,
        "SEVERE": 20
      },
      "GAD7": {
        "LIGHT": 40,
        "MODERATE": 42,
        "SEVERE": 18
      },
      "PHQ9": {
        "LIGHT": 38,
        "MODERATE": 44,
        "SEVERE": 18
      }
    },
    "topUniversities": [
      {
        "name": "Universitas Indonesia",
        "count": 450
      },
      {
        "name": "Institut Teknologi Bandung",
        "count": 380
      }
    ]
  }
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `EMAIL_EXISTS` | 400 | Email already registered |
| `INVALID_CREDENTIALS` | 401 | Wrong email or password |
| `UNAUTHORIZED` | 401 | No or invalid token |
| `FORBIDDEN` | 403 | No permission to access resource |
| `NOT_FOUND` | 404 | Resource not found |
| `VALIDATION_ERROR` | 422 | Request validation failed |
| `SERVER_ERROR` | 500 | Internal server error |

---

## Data Models

### User

```typescript
{
  id: string;              // Unique identifier
  email: string;           // User email (unique)
  name: string;            // Full name
  studentId: string;       // Student ID number
  age: number;             // Age (17-100)
  gender: string;          // "male" | "female" | "other"
  university: string;      // University name
  department: string;      // Department/Major
  photoUrl?: string;       // Photo URL (nullable)
  createdAt: string;       // ISO 8601 timestamp
  updatedAt: string;       // ISO 8601 timestamp
}
```

### Assessment Result

```typescript
{
  type: "PSS10" | "GAD7" | "PHQ9";
  score: number;           // Calculated score
  category: "LIGHT" | "MODERATE" | "SEVERE";
  percentage: number;      // Score as percentage of max
}
```

### Overall Result

```typescript
{
  id: string;              // Unique identifier
  userId: string;          // User ID (foreign key)
  assessments: AssessmentResult[];
  answers: number[];       // Array of answer indices
  timestamp: string;       // ISO 8601 timestamp
  createdAt: string;       // ISO 8601 timestamp
}
```

---

## Rate Limiting

- **Authentication endpoints**: 5 requests per minute per IP
- **Standard endpoints**: 60 requests per minute per user
- **Admin endpoints**: 100 requests per minute per admin

Response headers for rate limiting:
```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1516339200
```

---

## Webhooks (Optional)

### Result Saved Webhook

When a new result is saved, POST to configured webhook URL:

**Payload:**
```json
{
  "event": "result.saved",
  "timestamp": "2024-01-20T15:30:00Z",
  "data": {
    "resultId": "res_9876543210",
    "userId": "usr_1234567890",
    "highestCategory": "MODERATE",
    "needsAttention": false
  }
}
```

---

## Security Considerations

### 1. Password Storage
- Use bcrypt with minimum 10 rounds
- Never store plain passwords
- Implement password strength requirements

### 2. JWT Tokens
- Use HS256 or RS256 algorithm
- Set reasonable expiration (1 hour for access, 7 days for refresh)
- Include only necessary claims (userId, email, role)

### 3. Data Privacy
- Encrypt sensitive data at rest
- Use HTTPS for all communications
- Implement CORS properly
- Log access to sensitive endpoints

### 4. Input Validation
- Validate all input server-side
- Sanitize file uploads
- Limit file sizes (max 2MB for photos)
- Use parameterized queries to prevent SQL injection

---

## Database Schema (PostgreSQL Example)

```sql
-- Users table
CREATE TABLE users (
  id VARCHAR(50) PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  student_id VARCHAR(50),
  age INTEGER,
  gender VARCHAR(20),
  university VARCHAR(255),
  department VARCHAR(255),
  photo_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Results table
CREATE TABLE results (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) REFERENCES users(id),
  answers JSONB NOT NULL,
  timestamp TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Assessment scores table
CREATE TABLE assessment_scores (
  id SERIAL PRIMARY KEY,
  result_id VARCHAR(50) REFERENCES results(id),
  type VARCHAR(20) NOT NULL,
  score INTEGER NOT NULL,
  category VARCHAR(20) NOT NULL,
  percentage INTEGER NOT NULL
);

-- Indexes
CREATE INDEX idx_results_user_id ON results(user_id);
CREATE INDEX idx_results_timestamp ON results(timestamp);
CREATE INDEX idx_assessment_scores_result_id ON assessment_scores(result_id);
```

---

## Testing

### Example cURL Requests

**Register:**
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "name": "Test User"
  }'
```

**Login:**
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
```

**Save Result:**
```bash
curl -X POST http://localhost:8080/api/results \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "userId": "usr_1234567890",
    "assessments": [...],
    "answers": [...],
    "timestamp": "2024-01-20T15:30:00Z"
  }'
```

---

## Version History

- **v1.0** (2024-01-20): Initial API specification

---

## Support

For API support or questions:
- Email: api-support@sadassessment.com
- Docs: https://docs.sadassessment.com
- Status: https://status.sadassessment.com
