# Developer Guide - SAD Assessment

Panduan lengkap untuk developer yang ingin memodifikasi atau mengembangkan aplikasi SAD Assessment.

## 📋 Table of Contents

1. [Arsitektur Aplikasi](#arsitektur-aplikasi)
2. [Flow Aplikasi](#flow-aplikasi)
3. [Cara Menambah Assessment Baru](#cara-menambah-assessment-baru)
4. [Cara Mengubah Scoring](#cara-mengubah-scoring)
5. [Integrasi dengan Backend](#integrasi-dengan-backend)
6. [Testing](#testing)
7. [Troubleshooting](#troubleshooting)

---

## Arsitektur Aplikasi

### Component Hierarchy

```
App.tsx (State Management)
├── LandingPage
│   └── Header (User info, Login/Logout)
├── AuthPage
│   ├── Login Form
│   └── Register Form
├── ProfilePage
│   ├── Photo Upload
│   └── Profile Form
├── QuestionPage
│   ├── Progress Bar
│   ├── Question Card
│   └── Navigation Buttons
└── ResultPage
    ├── Score Cards (PSS-10, GAD-7, PHQ-9)
    ├── Interpretations
    ├── Recommendations
    └── Download Button
```

### Data Flow

```
User Input → Validation → State Update → Storage → Display
                ↓
            Utils Functions
                ↓
            Type Checking
```

---

## Flow Aplikasi

### 1. User Journey - Mode Anonim

```
Landing Page → Questions → Results → Download/Restart
```

### 2. User Journey - Mode Login

```
Landing Page → Auth Page → Profile Page → Landing Page → 
Questions → Results → Download/Restart
```

### 3. State Management

```typescript
// Main App State
const [currentPage, setCurrentPage] = useState<PageType>('landing');
const [user, setUser] = useState<User | null>(null);
const [answers, setAnswers] = useState<number[]>([]);
```

---

## Cara Menambah Assessment Baru

### Step 1: Update Types

Edit `/types/index.ts`:

```typescript
// Tambahkan tipe baru
export type AssessmentType = 'PSS10' | 'GAD7' | 'PHQ9' | 'NEW_ASSESSMENT';
```

### Step 2: Tambah Questions

Edit `/data/questions.ts`:

```typescript
const NEW_ASSESSMENT_QUESTIONS: Question[] = [
  {
    id: 27, // Continue dari question terakhir
    type: 'NEW_ASSESSMENT',
    text: 'Pertanyaan 1...',
    options: ['Option 1', 'Option 2', ...],
    scores: [0, 1, 2, ...]
  },
  // ... questions lainnya
];

// Update ALL_QUESTIONS
export const ALL_QUESTIONS: Question[] = [
  ...PSS10_QUESTIONS,
  ...GAD7_QUESTIONS,
  ...PHQ9_QUESTIONS,
  ...NEW_ASSESSMENT_QUESTIONS
];

// Tambah metadata
export const ASSESSMENT_METADATA = {
  // ... existing
  NEW_ASSESSMENT: {
    name: 'New Assessment Name',
    shortName: 'NA',
    description: 'Description here',
    questionCount: 5,
    maxScore: 20,
    timeframe: '1 minggu terakhir'
  }
};
```

### Step 3: Update Scoring

Edit `/utils/scoring.ts`:

```typescript
// Tambah threshold
const CATEGORY_THRESHOLDS = {
  // ... existing
  NEW_ASSESSMENT: {
    LIGHT: { min: 0, max: 6 },
    MODERATE: { min: 7, max: 14 },
    SEVERE: { min: 15, max: 20 }
  }
};

// Tambah interpretasi
const interpretations = {
  // ... existing
  NEW_ASSESSMENT: {
    LIGHT: 'Interpretasi untuk kategori ringan...',
    MODERATE: 'Interpretasi untuk kategori sedang...',
    SEVERE: 'Interpretasi untuk kategori tinggi...'
  }
};

// Tambah nama
const names = {
  // ... existing
  NEW_ASSESSMENT: 'Nama Assessment'
};
```

### Step 4: Update ResultPage (Opsional)

Jika ingin custom display untuk assessment baru, edit `/components/ResultPage.tsx`:

```typescript
const getIconForType = (type: string) => {
  // ... existing
  if (type === 'NEW_ASSESSMENT') return <NewIcon className="w-8 h-8" />;
  // ...
};
```

---

## Cara Mengubah Scoring

### Mengubah Kategori Threshold

Edit `/utils/scoring.ts`:

```typescript
const CATEGORY_THRESHOLDS = {
  PSS10: {
    LIGHT: { min: 0, max: 10 },      // Ubah dari 13 ke 10
    MODERATE: { min: 11, max: 25 },  // Ubah dari 14-26 ke 11-25
    SEVERE: { min: 26, max: 40 }     // Ubah dari 27 ke 26
  },
  // ...
};
```

### Mengubah Cara Perhitungan

Jika ingin custom scoring logic:

```typescript
export function calculateAssessmentScore(
  type: AssessmentType,
  answers: number[]
): number {
  const questions = ALL_QUESTIONS.filter(q => q.type === type);
  let totalScore = 0;

  questions.forEach((question, index) => {
    const answerIndex = answers[question.id - 1];
    if (answerIndex !== undefined) {
      // Custom logic di sini
      const baseScore = question.scores[answerIndex];
      
      // Contoh: Apply weight
      const weight = 1.5; // Beri bobot lebih besar
      totalScore += baseScore * weight;
    }
  });

  return Math.round(totalScore); // Round hasil
}
```

### Menambah Custom Category

Jika ingin lebih dari 3 kategori (LIGHT/MODERATE/SEVERE):

```typescript
// Update types
export type Category = 'MINIMAL' | 'LIGHT' | 'MODERATE' | 'SEVERE' | 'EXTREME';

// Update threshold
const CATEGORY_THRESHOLDS = {
  PSS10: {
    MINIMAL: { min: 0, max: 5 },
    LIGHT: { min: 6, max: 13 },
    MODERATE: { min: 14, max: 26 },
    SEVERE: { min: 27, max: 35 },
    EXTREME: { min: 36, max: 40 }
  }
};

// Update determineCategory function
export function determineCategory(
  type: AssessmentType,
  score: number
): Category {
  const thresholds = CATEGORY_THRESHOLDS[type];
  
  if (score >= thresholds.EXTREME.min) return 'EXTREME';
  if (score >= thresholds.SEVERE.min) return 'SEVERE';
  if (score >= thresholds.MODERATE.min) return 'MODERATE';
  if (score >= thresholds.LIGHT.min) return 'LIGHT';
  return 'MINIMAL';
}
```

---

## Integrasi dengan Backend

### Setup API Service

Buat file `/services/api.ts`:

```typescript
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api';

// Generic fetch wrapper
async function fetchAPI(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.statusText}`);
  }

  return response.json();
}

// Auth API
export const authAPI = {
  login: async (email: string, password: string) => {
    return fetchAPI('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },
  
  register: async (userData: Partial<User>) => {
    return fetchAPI('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },
};

// User API
export const userAPI = {
  getProfile: async (userId: string) => {
    return fetchAPI(`/users/${userId}`);
  },
  
  updateProfile: async (userId: string, data: Partial<User>) => {
    return fetchAPI(`/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },
};

// Results API
export const resultsAPI = {
  save: async (result: OverallResult) => {
    return fetchAPI('/results', {
      method: 'POST',
      body: JSON.stringify(result),
    });
  },
  
  getUserResults: async (userId: string) => {
    return fetchAPI(`/results/user/${userId}`);
  },
};
```

### Update Storage Utils

Edit `/utils/storage.ts` untuk menggunakan API:

```typescript
import { authAPI, userAPI, resultsAPI } from '../services/api';

// Replace localStorage with API calls
export async function saveUser(user: User): Promise<void> {
  try {
    await userAPI.updateProfile(user.id, user);
    // Still save to localStorage as cache
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  } catch (error) {
    console.error('Failed to save user:', error);
    throw error;
  }
}

export async function saveResult(result: OverallResult): Promise<void> {
  try {
    await resultsAPI.save(result);
    // Save to localStorage as backup
    const results = getAllResults();
    results.push(result);
    localStorage.setItem(STORAGE_KEYS.RESULTS, JSON.stringify(results));
  } catch (error) {
    console.error('Failed to save result:', error);
    throw error;
  }
}
```

### Backend Endpoints (Java/Spring Boot Example)

```java
// UserController.java
@RestController
@RequestMapping("/api/users")
public class UserController {
    
    @GetMapping("/{userId}")
    public ResponseEntity<User> getUser(@PathVariable String userId) {
        // Implementation
    }
    
    @PutMapping("/{userId}")
    public ResponseEntity<User> updateUser(
        @PathVariable String userId,
        @RequestBody User user
    ) {
        // Implementation
    }
}

// ResultsController.java
@RestController
@RequestMapping("/api/results")
public class ResultsController {
    
    @PostMapping
    public ResponseEntity<AssessmentResult> saveResult(
        @RequestBody AssessmentResult result
    ) {
        // Implementation
    }
    
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<AssessmentResult>> getUserResults(
        @PathVariable String userId
    ) {
        // Implementation
    }
}
```

---

## Testing

### Unit Testing Example

```typescript
// utils/scoring.test.ts
import { calculateAssessmentScore, determineCategory } from './scoring';

describe('Scoring Utils', () => {
  test('calculates PSS-10 score correctly', () => {
    const answers = [1, 2, 1, 3, 2, 1, 2, 3, 1, 2]; // All questions answered
    const score = calculateAssessmentScore('PSS10', answers);
    expect(score).toBeLessThanOrEqual(40);
    expect(score).toBeGreaterThanOrEqual(0);
  });

  test('determines category correctly', () => {
    expect(determineCategory('PSS10', 10)).toBe('LIGHT');
    expect(determineCategory('PSS10', 20)).toBe('MODERATE');
    expect(determineCategory('PSS10', 30)).toBe('SEVERE');
  });
});
```

### Manual Testing Checklist

- [ ] User bisa login dan register
- [ ] User bisa mengisi profil lengkap
- [ ] Photo upload berfungsi dengan baik
- [ ] Semua 26 pertanyaan ditampilkan dengan benar
- [ ] Progress bar update setiap pertanyaan
- [ ] Navigasi (Next/Back) berfungsi
- [ ] Hasil kalkulasi sesuai dengan standar
- [ ] Download hasil berisi data lengkap
- [ ] Mode anonim berfungsi (tanpa login)
- [ ] Data tersimpan di localStorage
- [ ] Logout menghapus session

---

## Troubleshooting

### Issue: Type Errors

**Problem**: TypeScript errors saat import types

**Solution**:
```typescript
// Pastikan import dari lokasi yang benar
import { User } from '../types';  // Bukan dari '../App'
```

### Issue: Questions Tidak Muncul

**Problem**: Pertanyaan tidak ditampilkan

**Solution**: Check:
1. Apakah `ALL_QUESTIONS` sudah include semua question arrays?
2. Apakah `id` pertanyaan sequential dan unique?
3. Check console untuk errors

### Issue: Scoring Tidak Akurat

**Problem**: Hasil skor tidak sesuai dengan yang diharapkan

**Solution**:
1. Check reverse scoring untuk PSS-10
2. Verify threshold values di `CATEGORY_THRESHOLDS`
3. Test dengan manual calculation

### Issue: LocalStorage Full

**Problem**: "QuotaExceededError" di browser

**Solution**:
```typescript
// Add error handling
try {
  localStorage.setItem(key, value);
} catch (e) {
  if (e.name === 'QuotaExceededError') {
    // Clear old data atau notify user
    console.error('Storage full!');
  }
}
```

### Issue: Photo Upload Too Large

**Problem**: Browser crash saat upload foto besar

**Solution**: Add file size check
```typescript
const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0];
  if (file) {
    // Check file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      alert('Ukuran foto maksimal 2MB');
      return;
    }
    // ... rest of code
  }
};
```

---

## Best Practices

### 1. Code Organization

- ✅ Pisahkan logic dan UI
- ✅ Gunakan TypeScript untuk type safety
- ✅ Buat utility functions yang reusable
- ✅ Comment code yang kompleks

### 2. State Management

- ✅ Minimal state di component level
- ✅ Lift state up ke parent jika shared
- ✅ Gunakan useState untuk local state
- ✅ Consider Context API untuk global state

### 3. Performance

- ✅ Memoize expensive calculations
- ✅ Lazy load components jika perlu
- ✅ Optimize images (compress, lazy load)
- ✅ Debounce user input jika perlu

### 4. Security

- ✅ Validate all user input
- ✅ Sanitize data sebelum display
- ✅ Never store sensitive data di localStorage
- ✅ Use HTTPS in production
- ✅ Implement CSRF protection

---

## Additional Resources

- [PSS-10 Official Documentation](https://www.cmu.edu/dietrich/psychology/stress-immunity-disease-lab/scales/index.html)
- [GAD-7 Documentation](https://www.phqscreeners.com/)
- [PHQ-9 Documentation](https://www.phqscreeners.com/)
- [React Best Practices](https://react.dev/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/)

---

## Changelog

### Version 1.0.0 (Current)
- ✅ Initial release
- ✅ PSS-10, GAD-7, PHQ-9 implementation
- ✅ Modular code structure
- ✅ LocalStorage for demo
- ✅ Profile management
- ✅ Result download

### Future Versions
- 🔜 Backend integration
- 🔜 PDF export
- 🔜 Multi-language support
- 🔜 Admin dashboard
- 🔜 Analytics

---

**Happy Coding! 🚀**
