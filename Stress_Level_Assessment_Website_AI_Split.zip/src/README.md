# SAD Assessment - Stress, Anxiety, Depression Assessment

Website penilaian kesehatan mental untuk mahasiswa baru menggunakan instrumen standar klinis PSS-10, GAD-7, dan PHQ-9.

## 🎯 Fitur Utama

- **Assessment Komprehensif**: 26 pertanyaan berdasarkan 3 instrumen standar
  - PSS-10: Perceived Stress Scale (10 pertanyaan, skala 0-4)
  - GAD-7: Generalized Anxiety Disorder (7 pertanyaan, skala 0-3)
  - PHQ-9: Patient Health Questionnaire (9 pertanyaan, skala 0-3)

- **Authentication Opsional**
  - Mode anonim: Langsung mulai tes tanpa login
  - Mode login: Simpan profil dan riwayat hasil

- **Profil Pengguna**
  - Upload foto profil (ditampilkan dalam bentuk bulat)
  - Data lengkap: Nama, NIM, Usia, Gender, Universitas, Program Studi

- **Hasil Detail**
  - Skor dan kategori untuk setiap assessment (LIGHT/MODERATE/SEVERE)
  - Interpretasi hasil dalam bahasa Indonesia
  - Rekomendasi berdasarkan tingkat severity
  - Download hasil dalam format .txt

## 📁 Struktur Kode

Kode telah dipisahkan secara modular untuk memudahkan maintenance:

```
/
├── App.tsx                    # Main application component
├── types/
│   └── index.ts              # Type definitions (User, Question, Result, dll)
├── data/
│   └── questions.ts          # Data pertanyaan PSS-10, GAD-7, PHQ-9
├── utils/
│   ├── scoring.ts            # Logika kalkulasi skor dan kategorisasi
│   ├── storage.ts            # LocalStorage operations
│   ├── validation.ts         # Form validation functions
│   └── formatters.ts         # Date formatting & utilities
└── components/
    ├── LandingPage.tsx       # Halaman landing
    ├── AuthPage.tsx          # Login & register
    ├── ProfilePage.tsx       # Form profil pengguna
    ├── QuestionPage.tsx      # Assessment questions
    └── ResultPage.tsx        # Hasil assessment
```

## 🔧 Cara Mengubah Code

### 1. Mengubah Pertanyaan Assessment

Edit file `/data/questions.ts`:

```typescript
// Contoh mengubah pertanyaan PSS-10
const PSS10_QUESTIONS: Question[] = [
  {
    id: 1,
    type: 'PSS10',
    text: 'Pertanyaan baru Anda...',
    options: ['Tidak Pernah', ...],
    scores: [0, 1, 2, 3, 4]
  },
  // ...
];
```

### 2. Mengubah Logika Scoring

Edit file `/utils/scoring.ts`:

```typescript
// Contoh mengubah threshold kategori
const CATEGORY_THRESHOLDS = {
  PSS10: {
    LIGHT: { min: 0, max: 13 },      // Ubah nilai di sini
    MODERATE: { min: 14, max: 26 },
    SEVERE: { min: 27, max: 40 }
  },
  // ...
};
```

### 3. Mengubah Interpretasi Hasil

Edit function `getCategoryInterpretation` di `/utils/scoring.ts`:

```typescript
export function getCategoryInterpretation(
  type: AssessmentType,
  category: 'LIGHT' | 'MODERATE' | 'SEVERE'
): string {
  const interpretations = {
    PSS10: {
      LIGHT: 'Interpretasi baru Anda...',
      // ...
    },
    // ...
  };
  return interpretations[type][category];
}
```

### 4. Mengubah Validasi Form

Edit file `/utils/validation.ts`:

```typescript
// Contoh mengubah validasi NIM
export function isValidStudentId(studentId: string): boolean {
  return /^\d{8,}$/.test(studentId); // Ubah regex atau logika
}
```

## 📊 Standar Klinis

### PSS-10 (Perceived Stress Scale)
- **Range**: 0-40
- **Kategori**:
  - 0-13: Low stress (LIGHT)
  - 14-26: Moderate stress (MODERATE)
  - 27-40: High stress (SEVERE)
- **Reverse scoring**: Items 4, 5, 7, 8 (sudah dihandle otomatis dalam code)

### GAD-7 (Generalized Anxiety Disorder)
- **Range**: 0-21
- **Kategori**:
  - 0-4: Minimal anxiety (LIGHT)
  - 5-14: Moderate anxiety (MODERATE)
  - 15-21: Severe anxiety (SEVERE)

### PHQ-9 (Patient Health Questionnaire)
- **Range**: 0-27
- **Kategori**:
  - 0-4: Minimal depression (LIGHT)
  - 5-14: Moderate depression (MODERATE)
  - 15-27: Severe depression (SEVERE)

## 💾 Data Storage

Saat ini menggunakan **localStorage** untuk demo:
- Key prefix: `sad_*`
- Data tersimpan di browser user
- **Untuk production**: Integrasikan dengan backend (Java/Spring Boot atau lainnya)

### Migration ke Backend

File `/utils/storage.ts` sudah siap untuk diganti dengan API calls:

```typescript
// Contoh: Ganti dengan API call
export async function saveUser(user: User): Promise<void> {
  await fetch('/api/users', {
    method: 'POST',
    body: JSON.stringify(user),
    headers: { 'Content-Type': 'application/json' }
  });
}
```

## 🎨 Styling

- **Framework**: Tailwind CSS v4.0
- **Color scheme**: Blue to Purple gradient
- **Typography**: Default dari `/styles/globals.css`
- **Responsive**: Mobile-first design

## ⚠️ Important Notes

1. **Protected Files**: Jangan edit file di `/components/figma/ImageWithFallback.tsx`
2. **Validation**: Semua input user divalidasi (lihat `/utils/validation.ts`)
3. **Security**: Password tidak di-hash (implement bcrypt untuk production)
4. **Privacy**: Aplikasi ini untuk screening, bukan diagnosis klinis

## 🚀 Next Steps untuk Production

1. [ ] Integrasikan dengan backend API
2. [ ] Implement authentication yang proper (JWT/OAuth)
3. [ ] Hash password menggunakan bcrypt
4. [ ] Database untuk menyimpan user dan results
5. [ ] Rate limiting untuk prevent abuse
6. [ ] SSL/HTTPS untuk keamanan data
7. [ ] Backup dan recovery system
8. [ ] Analytics untuk tracking usage
9. [ ] Export results dalam format PDF
10. [ ] Multi-language support

## 📝 License

Untuk tujuan educational dan research. Pastikan comply dengan regulasi kesehatan mental dan privacy laws di wilayah Anda.

## 🤝 Contributing

Jika ingin menambah fitur atau memperbaiki bug:
1. Edit file yang relevan sesuai struktur modular
2. Test perubahan Anda
3. Dokumentasikan perubahan

## 📞 Support

Untuk pertanyaan atau bantuan, silakan hubungi tim development atau buat issue di repository.

---

**Disclaimer**: Aplikasi ini menggunakan instrumen standar klinis untuk screening awal. Hasil bukan diagnosis klinis dan tidak menggantikan evaluasi profesional kesehatan mental.
