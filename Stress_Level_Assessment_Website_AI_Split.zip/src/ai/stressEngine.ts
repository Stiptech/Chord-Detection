import { AssessmentType, AssessmentResult } from '../types';
import { ALL_QUESTIONS, ASSESSMENT_METADATA } from '../data/questions';

/**
 * Kategori threshold berdasarkan standar klinis
 */
const CATEGORY_THRESHOLDS = {
  PSS10: {
    LIGHT: { min: 0, max: 13 },
    MODERATE: { min: 14, max: 26 },
    SEVERE: { min: 27, max: 40 }
  },
  GAD7: {
    LIGHT: { min: 0, max: 4 },
    MODERATE: { min: 5, max: 14 },
    SEVERE: { min: 15, max: 21 }
  },
  PHQ9: {
    LIGHT: { min: 0, max: 4 },
    MODERATE: { min: 5, max: 14 },
    SEVERE: { min: 15, max: 27 }
  }
};

/**
 * Hitung skor untuk assessment tertentu
 */
export function calculateAssessmentScore(
  type: AssessmentType,
  answers: number[]
): number {
  const questions = ALL_QUESTIONS.filter(q => q.type === type);
  let totalScore = 0;

  questions.forEach((question, index) => {
    const answerIndex = answers[question.id - 1];
    if (answerIndex !== undefined) {
      totalScore += question.scores[answerIndex];
    }
  });

  return totalScore;
}

/**
 * Tentukan kategori berdasarkan skor
 */
export function determineCategory(
  type: AssessmentType,
  score: number
): 'LIGHT' | 'MODERATE' | 'SEVERE' {
  const thresholds = CATEGORY_THRESHOLDS[type];

  if (score >= thresholds.SEVERE.min) {
    return 'SEVERE';
  } else if (score >= thresholds.MODERATE.min) {
    return 'MODERATE';
  } else {
    return 'LIGHT';
  }
}

/**
 * Hitung persentase dari skor maksimal
 */
export function calculatePercentage(
  type: AssessmentType,
  score: number
): number {
  const maxScore = ASSESSMENT_METADATA[type].maxScore;
  return Math.round((score / maxScore) * 100);
}

/**
 * Hitung hasil untuk satu assessment
 */
export function calculateAssessmentResult(
  type: AssessmentType,
  answers: number[]
): AssessmentResult {
  const score = calculateAssessmentScore(type, answers);
  const category = determineCategory(type, score);
  const percentage = calculatePercentage(type, score);

  return {
    type,
    score,
    category,
    percentage
  };
}

/**
 * Hitung semua hasil assessment dari jawaban lengkap
 */
export function calculateAllResults(answers: number[]): AssessmentResult[] {
  const types: AssessmentType[] = ['PSS10', 'GAD7', 'PHQ9'];
  return types.map(type => calculateAssessmentResult(type, answers));
}

/**
 * Get interpretasi text untuk kategori
 */
export function getCategoryInterpretation(
  type: AssessmentType,
  category: 'LIGHT' | 'MODERATE' | 'SEVERE'
): string {
  const interpretations = {
    PSS10: {
      LIGHT: 'Tingkat stres Anda berada dalam kategori ringan. Anda mampu mengelola tekanan dengan baik.',
      MODERATE: 'Tingkat stres Anda berada dalam kategori sedang. Pertimbangkan untuk menggunakan teknik manajemen stres.',
      SEVERE: 'Tingkat stres Anda berada dalam kategori tinggi. Sangat disarankan untuk mencari dukungan profesional.'
    },
    GAD7: {
      LIGHT: 'Tingkat kecemasan Anda berada dalam kategori ringan. Anda menunjukkan tingkat kecemasan yang normal.',
      MODERATE: 'Tingkat kecemasan Anda berada dalam kategori sedang. Pertimbangkan untuk berbicara dengan konselor.',
      SEVERE: 'Tingkat kecemasan Anda berada dalam kategori tinggi. Sangat disarankan untuk berkonsultasi dengan profesional kesehatan mental.'
    },
    PHQ9: {
      LIGHT: 'Tingkat depresi Anda berada dalam kategori ringan. Mood Anda relatif stabil.',
      MODERATE: 'Tingkat depresi Anda berada dalam kategori sedang. Pertimbangkan untuk berbicara dengan konselor atau psikolog.',
      SEVERE: 'Tingkat depresi Anda berada dalam kategori tinggi. Sangat penting untuk segera berkonsultasi dengan profesional kesehatan mental.'
    }
  };

  return interpretations[type][category];
}

/**
 * Get warna badge berdasarkan kategori
 */
export function getCategoryColor(
  category: 'LIGHT' | 'MODERATE' | 'SEVERE'
): string {
  const colors = {
    LIGHT: 'bg-green-100 text-green-800 border-green-300',
    MODERATE: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    SEVERE: 'bg-red-100 text-red-800 border-red-300'
  };
  return colors[category];
}

/**
 * Get label Indonesia untuk kategori
 */
export function getCategoryLabel(
  category: 'LIGHT' | 'MODERATE' | 'SEVERE'
): string {
  const labels = {
    LIGHT: 'Ringan',
    MODERATE: 'Sedang',
    SEVERE: 'Tinggi'
  };
  return labels[category];
}

/**
 * Get nama assessment dalam bahasa Indonesia
 */
export function getAssessmentName(type: AssessmentType): string {
  const names = {
    PSS10: 'Stres',
    GAD7: 'Kecemasan',
    PHQ9: 'Depresi'
  };
  return names[type];
}
