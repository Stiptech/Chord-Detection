import { Brain, AlertCircle, CheckCircle, AlertTriangle, RefreshCw, Download, LogOut, UserCircle, LogIn } from 'lucide-react';
import { User } from '../types';
import { calculateAllResults, getCategoryInterpretation, getCategoryColor, getCategoryLabel, getAssessmentName } from '../utils/scoring';
import { formatDate, formatDateForFilename } from '../utils/formatters';
import { saveResult } from '../utils/storage';
import { ASSESSMENT_METADATA } from '../data/questions';

interface ResultPageProps {
  answers: number[];
  user: User | null;
  onRestart: () => void;
  onGoToAuth: () => void;
  onGoToProfile: () => void;
  onLogout: () => void;
}

export function ResultPage({ answers, user, onRestart, onGoToAuth, onGoToProfile, onLogout }: ResultPageProps) {
  // Calculate all results
  const results = calculateAllResults(answers);
  
  // Save results if user is logged in
  if (user) {
    const resultData = {
      assessments: results,
      timestamp: new Date().toISOString(),
      userId: user.id
    };
    saveResult(resultData);
  }

  // Determine highest severity
  const severityRank = { LIGHT: 1, MODERATE: 2, SEVERE: 3 };
  const primaryResult = results.reduce((max, result) =>
    severityRank[result.category] > severityRank[max.category] ? result : max
  );

  const getSeverityIcon = (category: 'LIGHT' | 'MODERATE' | 'SEVERE') => {
    if (category === 'SEVERE') return <AlertCircle className="w-12 h-12 text-red-600" />;
    if (category === 'MODERATE') return <AlertTriangle className="w-12 h-12 text-yellow-600" />;
    return <CheckCircle className="w-12 h-12 text-green-600" />;
  };

  const getIconForType = (type: string) => {
    if (type === 'PSS10') return <Brain className="w-8 h-8 text-blue-600" />;
    if (type === 'GAD7') return <AlertTriangle className="w-8 h-8 text-yellow-600" />;
    return <AlertCircle className="w-8 h-8 text-purple-600" />;
  };

  const getColorForType = (type: string) => {
    if (type === 'PSS10') return 'bg-blue-100';
    if (type === 'GAD7') return 'bg-yellow-100';
    return 'bg-purple-100';
  };

  const handleDownload = () => {
    const userData = user ? `Nama: ${user.name}
NIM: ${user.studentId}
Usia: ${user.age}
Gender: ${user.gender === 'male' ? 'Laki-laki' : user.gender === 'female' ? 'Perempuan' : 'Lainnya'}
Universitas: ${user.university}
Program Studi: ${user.department}

` : 'Pengguna: Anonim (Belum login)\n\n';

    let resultText = `Hasil SAD Assessment (Stress, Anxiety, Depression)
=================================
${userData}HASIL TES:
=================================
`;

    results.forEach(result => {
      const metadata = ASSESSMENT_METADATA[result.type];
      resultText += `
${metadata.shortName} (${getAssessmentName(result.type)}):
  Skor: ${result.score}/${metadata.maxScore}
  Persentase: ${result.percentage}%
  Kategori: ${getCategoryLabel(result.category)}
  Interpretasi: ${getCategoryInterpretation(result.type, result.category)}
`;
    });

    resultText += `
KESIMPULAN:
=================================
Domain dengan tingkat tertinggi: ${getAssessmentName(primaryResult.type)}
Kategori: ${getCategoryLabel(primaryResult.category)}

Tanggal: ${formatDate(new Date())}
`;

    const blob = new Blob([resultText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const filename = `sad-assessment-${user?.studentId || 'anonymous'}-${formatDateForFilename(new Date())}.txt`;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl">SAD Assessment</span>
          </div>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <button
                  onClick={onGoToProfile}
                  className="hover:bg-gray-50 rounded-full p-1 transition-all"
                >
                  {user.photoUrl ? (
                    <img 
                      src={user.photoUrl} 
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover border-2 border-purple-200"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                      <UserCircle className="w-6 h-6 text-white" />
                    </div>
                  )}
                </button>
                <button
                  onClick={onLogout}
                  className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-all"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <button
                onClick={onGoToAuth}
                className="flex items-center gap-2 px-4 py-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-all"
              >
                <LogIn className="w-5 h-5" />
                <span className="hidden sm:inline">Masuk</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Results */}
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h1 className="mb-4 text-gray-900">Hasil Assessment Anda</h1>
          {user ? (
            <p className="text-gray-600">
              {user.name} - {user.studentId}
            </p>
          ) : (
            <p className="text-gray-600">
              Mode Anonim -{' '}
              <button onClick={onGoToAuth} className="text-purple-600 hover:text-purple-700 underline">
                Login untuk menyimpan hasil
              </button>
            </p>
          )}
        </div>

        {/* Primary Result Card */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-12 mb-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              {getSeverityIcon(primaryResult.category)}
            </div>
            <h2 className="mb-2 text-gray-900">
              Domain dengan Tingkat Tertinggi: {getAssessmentName(primaryResult.type)}
            </h2>
            <div className={`inline-block px-4 py-2 rounded-lg border-2 ${getCategoryColor(primaryResult.category)}`}>
              {getCategoryLabel(primaryResult.category)}
            </div>
          </div>
        </div>

        {/* Detailed Scores */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {results.map(result => {
            const metadata = ASSESSMENT_METADATA[result.type];
            return (
              <div key={result.type} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="text-center mb-4">
                  <div className={`w-16 h-16 ${getColorForType(result.type)} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                    {getIconForType(result.type)}
                  </div>
                  <h3 className="text-gray-900 mb-2">{metadata.shortName}</h3>
                  <p className="text-gray-600 text-sm mb-4">{getAssessmentName(result.type)}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4 mb-3">
                  <div className="text-center mb-2">
                    <span className="text-3xl text-gray-900">{result.score}</span>
                    <span className="text-gray-600">/{metadata.maxScore}</span>
                  </div>
                  <div className="text-center text-sm text-gray-600">{result.percentage}%</div>
                </div>
                <div className={`text-center px-3 py-2 rounded-lg border ${getCategoryColor(result.category)}`}>
                  {getCategoryLabel(result.category)}
                </div>
              </div>
            );
          })}
        </div>

        {/* Interpretations */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 mb-8">
          <h3 className="mb-6 text-gray-900 text-center">Interpretasi Hasil</h3>
          <div className="space-y-4">
            {results.map(result => (
              <div key={result.type} className={`border rounded-lg p-4 ${
                result.category === 'SEVERE' ? 'bg-red-50 border-red-200' :
                result.category === 'MODERATE' ? 'bg-yellow-50 border-yellow-200' :
                'bg-green-50 border-green-200'
              }`}>
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    {result.category === 'SEVERE' ? '⚠️' :
                     result.category === 'MODERATE' ? '💡' : '✅'}
                  </div>
                  <div>
                    <h4 className={`mb-1 ${
                      result.category === 'SEVERE' ? 'text-red-800' :
                      result.category === 'MODERATE' ? 'text-yellow-800' :
                      'text-green-800'
                    }`}>
                      {ASSESSMENT_METADATA[result.type].shortName} - {getCategoryLabel(result.category)}
                    </h4>
                    <p className={
                      result.category === 'SEVERE' ? 'text-red-700' :
                      result.category === 'MODERATE' ? 'text-yellow-700' :
                      'text-green-700'
                    }>
                      {getCategoryInterpretation(result.type, result.category)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 mb-8">
          <h3 className="mb-6 text-gray-900 text-center">Rekomendasi</h3>
          <div className="space-y-4">
            {primaryResult.category === 'SEVERE' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-800">
                  ⚠️ Hasil menunjukkan tingkat {getAssessmentName(primaryResult.type).toLowerCase()} yang tinggi. 
                  Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental 
                  atau layanan konseling kampus Anda.
                </p>
              </div>
            )}
            {primaryResult.category === 'MODERATE' && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800">
                  💡 Hasil menunjukkan tingkat {getAssessmentName(primaryResult.type).toLowerCase()} yang sedang. 
                  Pertimbangkan untuk berbicara dengan konselor atau psikolog untuk mendapatkan 
                  strategi coping yang lebih baik.
                </p>
              </div>
            )}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800">
                📚 Manfaatkan layanan konseling dan kesehatan mental yang tersedia di kampus Anda.
              </p>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-green-800">
                🌱 Praktikkan self-care: tidur cukup, olahraga teratur, dan jaga pola makan sehat.
              </p>
            </div>
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
              <p className="text-purple-800">
                🤝 Jangan ragu untuk berbicara dengan teman, keluarga, atau support group mahasiswa.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={handleDownload}
            className="px-8 py-3 bg-white border-2 border-purple-600 text-purple-600 rounded-lg hover:bg-purple-50 transition-all shadow-sm hover:shadow-md inline-flex items-center justify-center gap-2"
          >
            <Download className="w-5 h-5" />
            Download Hasil
          </button>
          <button
            onClick={onRestart}
            className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl inline-flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            Ulangi Tes
          </button>
        </div>

        {/* Disclaimer */}
        <div className="mt-12 text-center text-sm text-gray-500 max-w-3xl mx-auto">
          <p>
            <strong>Disclaimer:</strong> Tes ini menggunakan instrumen standar PSS-10, GAD-7, dan PHQ-9 
            untuk tujuan skrining awal. Hasil ini bukan diagnosis klinis dan tidak menggantikan evaluasi 
            profesional. Jika Anda mengalami gejala yang mengganggu atau berkepanjangan, 
            silakan berkonsultasi dengan profesional kesehatan mental yang berkualifikasi.
          </p>
        </div>
      </div>
    </div>
  );
}
