import { Question } from '../types';

/**
 * PSS-10 (Perceived Stress Scale)
 * 10 pertanyaan dengan skala 0-4
 * Mengukur tingkat stress dalam 1 bulan terakhir
 */
const PSS10_QUESTIONS: Question[] = [
  {
    id: 1,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa kesal karena sesuatu yang terjadi di luar dugaan?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [0, 1, 2, 3, 4]
  },
  {
    id: 2,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa tidak mampu mengendalikan hal-hal penting dalam hidup Anda?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [0, 1, 2, 3, 4]
  },
  {
    id: 3,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa gugup dan stres?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [0, 1, 2, 3, 4]
  },
  {
    id: 4,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa yakin dengan kemampuan Anda menangani masalah pribadi?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [4, 3, 2, 1, 0] // Reverse scored
  },
  {
    id: 5,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa bahwa segala sesuatu berjalan sesuai keinginan Anda?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [4, 3, 2, 1, 0] // Reverse scored
  },
  {
    id: 6,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa tidak dapat mengatasi semua hal yang harus Anda lakukan?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [0, 1, 2, 3, 4]
  },
  {
    id: 7,
    type: 'PSS10',
    text: 'Seberapa sering Anda mampu mengendalikan hal-hal yang mengganggu dalam hidup Anda?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [4, 3, 2, 1, 0] // Reverse scored
  },
  {
    id: 8,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa bahwa Anda menguasai keadaan?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [4, 3, 2, 1, 0] // Reverse scored
  },
  {
    id: 9,
    type: 'PSS10',
    text: 'Seberapa sering Anda marah karena hal-hal di luar kendali Anda?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [0, 1, 2, 3, 4]
  },
  {
    id: 10,
    type: 'PSS10',
    text: 'Seberapa sering Anda merasa kesulitan menumpuk sehingga tidak dapat mengatasinya?',
    options: ['Tidak Pernah', 'Hampir Tidak Pernah', 'Kadang-kadang', 'Cukup Sering', 'Sangat Sering'],
    scores: [0, 1, 2, 3, 4]
  }
];

/**
 * GAD-7 (Generalized Anxiety Disorder)
 * 7 pertanyaan dengan skala 0-3
 * Mengukur tingkat kecemasan dalam 2 minggu terakhir
 */
const GAD7_QUESTIONS: Question[] = [
  {
    id: 11,
    type: 'GAD7',
    text: 'Merasa gugup, cemas, atau gelisah',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 12,
    type: 'GAD7',
    text: 'Tidak mampu menghentikan atau mengendalikan kekhawatiran',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 13,
    type: 'GAD7',
    text: 'Terlalu banyak khawatir tentang berbagai hal',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 14,
    type: 'GAD7',
    text: 'Kesulitan untuk rileks',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 15,
    type: 'GAD7',
    text: 'Sangat gelisah sehingga sulit untuk duduk diam',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 16,
    type: 'GAD7',
    text: 'Menjadi mudah terganggu atau mudah marah',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 17,
    type: 'GAD7',
    text: 'Merasa takut seolah-olah sesuatu yang buruk akan terjadi',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  }
];

/**
 * PHQ-9 (Patient Health Questionnaire)
 * 9 pertanyaan dengan skala 0-3
 * Mengukur tingkat depresi dalam 2 minggu terakhir
 */
const PHQ9_QUESTIONS: Question[] = [
  {
    id: 18,
    type: 'PHQ9',
    text: 'Sedikit minat atau kesenangan dalam melakukan sesuatu',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 19,
    type: 'PHQ9',
    text: 'Merasa sedih, tertekan, atau putus asa',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 20,
    type: 'PHQ9',
    text: 'Kesulitan tidur atau tidur terlalu banyak',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 21,
    type: 'PHQ9',
    text: 'Merasa lelah atau memiliki sedikit energi',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 22,
    type: 'PHQ9',
    text: 'Nafsu makan buruk atau makan berlebihan',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 23,
    type: 'PHQ9',
    text: 'Merasa buruk tentang diri sendiri atau merasa gagal atau mengecewakan diri sendiri atau keluarga',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 24,
    type: 'PHQ9',
    text: 'Kesulitan berkonsentrasi pada hal-hal, seperti membaca koran atau menonton televisi',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 25,
    type: 'PHQ9',
    text: 'Bergerak atau berbicara sangat lambat sehingga orang lain menyadarinya, atau sebaliknya sangat gelisah atau gelisah sehingga Anda bergerak lebih banyak dari biasanya',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  },
  {
    id: 26,
    type: 'PHQ9',
    text: 'Pikiran bahwa Anda lebih baik mati atau menyakiti diri sendiri dengan cara tertentu',
    options: ['Tidak Sama Sekali', 'Beberapa Hari', 'Lebih dari Setengah Hari', 'Hampir Setiap Hari'],
    scores: [0, 1, 2, 3]
  }
];

// Gabungkan semua pertanyaan
export const ALL_QUESTIONS: Question[] = [
  ...PSS10_QUESTIONS,
  ...GAD7_QUESTIONS,
  ...PHQ9_QUESTIONS
];

// Export individual question sets
export { PSS10_QUESTIONS, GAD7_QUESTIONS, PHQ9_QUESTIONS };

// Metadata
export const ASSESSMENT_METADATA = {
  PSS10: {
    name: 'Perceived Stress Scale',
    shortName: 'PSS-10',
    description: 'Mengukur tingkat stres yang dirasakan dalam 1 bulan terakhir',
    questionCount: 10,
    maxScore: 40,
    timeframe: '1 bulan terakhir'
  },
  GAD7: {
    name: 'Generalized Anxiety Disorder',
    shortName: 'GAD-7',
    description: 'Mengukur tingkat kecemasan dalam 2 minggu terakhir',
    questionCount: 7,
    maxScore: 21,
    timeframe: '2 minggu terakhir'
  },
  PHQ9: {
    name: 'Patient Health Questionnaire',
    shortName: 'PHQ-9',
    description: 'Mengukur tingkat depresi dalam 2 minggu terakhir',
    questionCount: 9,
    maxScore: 27,
    timeframe: '2 minggu terakhir'
  }
};
