// User Types
export type User = {
  id: string;
  email: string;
  name: string;
  studentId: string;
  age: number;
  gender: string;
  university: string;
  department: string;
  photoUrl?: string;
};

// Assessment Types
export type AssessmentType = 'PSS10' | 'GAD7' | 'PHQ9';

export type Question = {
  id: number;
  type: AssessmentType;
  text: string;
  options: string[];
  scores: number[];
};

export type AssessmentResult = {
  type: AssessmentType;
  score: number;
  category: 'LIGHT' | 'MODERATE' | 'SEVERE';
  percentage: number;
};

export type OverallResult = {
  assessments: AssessmentResult[];
  timestamp: string;
  userId?: string;
};

// Page Navigation Types
export type PageType = 'landing' | 'auth' | 'profile' | 'questions' | 'results';
