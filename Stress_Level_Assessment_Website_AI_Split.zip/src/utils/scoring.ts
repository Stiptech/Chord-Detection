// Bridge module to the AI stress engine
// All scoring logic is implemented in src/ai/stressEngine.ts

export * from '../ai/stressEngine';
