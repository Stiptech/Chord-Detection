import { User, OverallResult } from '../types';

/**
 * LocalStorage Keys
 */
const STORAGE_KEYS = {
  CURRENT_USER: 'sad_current_user',
  USERS: 'sad_users',
  RESULTS: 'sad_results'
};

/**
 * User Storage Functions
 */
export function saveCurrentUser(user: User): void {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
}

export function getCurrentUser(): User | null {
  const userStr = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  return userStr ? JSON.parse(userStr) : null;
}

export function removeCurrentUser(): void {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
}

export function getAllUsers(): User[] {
  const usersStr = localStorage.getItem(STORAGE_KEYS.USERS);
  return usersStr ? JSON.parse(usersStr) : [];
}

export function saveUser(user: User): void {
  const users = getAllUsers();
  const existingIndex = users.findIndex(u => u.id === user.id);
  
  if (existingIndex >= 0) {
    users[existingIndex] = user;
  } else {
    users.push(user);
  }
  
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

export function getUserByEmail(email: string): User | null {
  const users = getAllUsers();
  return users.find(u => u.email === email) || null;
}

/**
 * Result Storage Functions
 */
export function saveResult(result: OverallResult): void {
  const results = getAllResults();
  results.push(result);
  localStorage.setItem(STORAGE_KEYS.RESULTS, JSON.stringify(results));
}

export function getAllResults(): OverallResult[] {
  const resultsStr = localStorage.getItem(STORAGE_KEYS.RESULTS);
  return resultsStr ? JSON.parse(resultsStr) : [];
}

export function getUserResults(userId: string): OverallResult[] {
  const results = getAllResults();
  return results.filter(r => r.userId === userId);
}

/**
 * Clear all data (for testing purposes)
 */
export function clearAllData(): void {
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
}
