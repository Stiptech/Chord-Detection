/**
 * Validasi email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validasi NIM (Nomor Induk Mahasiswa)
 * Asumsi: NIM harus minimal 6 digit angka
 */
export function isValidStudentId(studentId: string): boolean {
  return /^\d{6,}$/.test(studentId);
}

/**
 * Validasi usia
 */
export function isValidAge(age: number): boolean {
  return age >= 17 && age <= 100;
}

/**
 * Validasi password
 * Minimal 6 karakter
 */
export function isValidPassword(password: string): boolean {
  return password.length >= 6;
}

/**
 * Validasi nama
 */
export function isValidName(name: string): boolean {
  return name.trim().length >= 2;
}

/**
 * Validasi profile completion
 */
export function isProfileComplete(user: {
  name: string;
  studentId: string;
  age: number;
  gender: string;
  university: string;
  department: string;
}): boolean {
  return (
    isValidName(user.name) &&
    isValidStudentId(user.studentId) &&
    isValidAge(user.age) &&
    user.gender.trim().length > 0 &&
    user.university.trim().length > 0 &&
    user.department.trim().length > 0
  );
}
